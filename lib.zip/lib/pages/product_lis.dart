import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:fruit/components/product_item.dart';

class ProductList extends StatefulWidget {
  dynamic changeTheme;
  bool isDark;
  String abc = "-----------------------";
  ProductList({required this.changeTheme, required this.isDark});
  @override
  State<ProductList> createState() => _ProductListState();
}

class _ProductListState extends State<ProductList> {
  bool isGrid = true;
  List<dynamic> data = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(Object context) {
    // TODO: implement build
    return Scaffold(
        floatingActionButton: FloatingActionButton(
            onPressed: () {
              setState(() {
                isGrid = isGrid ? false : true;
              });
            },
            child: Icon(Icons.catching_pokemon)),
        appBar: AppBar(
          backgroundColor: Colors.red,
          actions: [
          ElevatedButton(
              style: ElevatedButton.styleFrom(
                  shape: const StadiumBorder(),
                  backgroundColor:
                       Colors.red[200]),
              onPressed: () {
                // widget.abc;
                // print(widget.abc);
                widget.changeTheme();
              },
              child: Text(widget.isDark ? "Light Mode" : "Dark Mode"))
        ], title: Text("Fruit Products")),
        body: Column(
          children: [
            HeroImage(),
            Container(
              padding: EdgeInsets.only(left: 30),
              width:double.infinity,
              child:Text("Available Fruites",
              
            textAlign: TextAlign.start,
            style: TextStyle(fontSize: 30,fontFamily:"Ohbaby" ),
            
            ) ,
            ),
            
            Expanded(
                child: Padding(
              child: Listing(isGrid),
              padding: EdgeInsets.all(10),
            ))
          ],
        ));
  }
}


//! separeted widgets-------------------------------------------------------------------------
Widget HeroImage() {
  return Container(
    margin: EdgeInsets.only(top: 20, bottom: 10),
    width: double.infinity,
    height: 200,
    child: ListView.builder(
      itemCount: 5,
      scrollDirection: Axis.horizontal,
      itemBuilder: (context, index) {
        return Container(
          margin: EdgeInsets.all(10),
          width: 400,
          height: 200,
          foregroundDecoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/image/f3.png"),
              fit: BoxFit.fill,
            ),
          ),
        );
      },
    ),
  );
}

Widget Listing(isGrid) {
  return isGrid
      ? GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, mainAxisExtent: 230),
          itemCount: 20,
          itemBuilder: (context, index) {
            return ProdutItem(
                image_url: "assets/image/f1.png",
                title: "Rose apple/Water",
                description:
                    "Broadly there are two categories of fruits: fleshy fruits and dry fruits",
                price: 125);
          },
        )
      : ListView.builder(
          itemCount: 10,
          itemBuilder: (context, index) {
            return ProdutItem(
                image_url: "assets/image/f1.png",
                title: "Rose apple/Water",
                description:
                    "Broadly there are two categories of fruits: fleshy fruits and dry fruits",
                price: 123);
          });
}
