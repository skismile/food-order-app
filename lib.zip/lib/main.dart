import 'package:flutter/material.dart';
import 'package:fruit/pages/product_lis.dart';

void main() {
  runApp(FoodApp());
}

class FoodApp extends StatefulWidget {
  @override
  State<FoodApp> createState() => _FoodAppState();
}

class _FoodAppState extends State<FoodApp> {
  bool dark = false;

  changeTheme() {
    setState(() {
    dark = dark ? false : true;
      
    });
    // print(dark);
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      
      debugShowCheckedModeBanner: false,
      theme: dark?ThemeData.dark() : ThemeData.light(
    
      ),
    
      home: ProductList(changeTheme: changeTheme,isDark: dark,),
    );
  }
}
